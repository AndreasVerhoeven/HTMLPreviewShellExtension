HTML Explorer Thumbnails
=====================================================================
(c) copyright Andreas Verhoeven, 2008 | andreasverhoeven@hotmail.com



I.  DESCRIPTION
II. INSTALLATION
III.UNINSTALLATION
IV. DISTRIBUTION


I. DESCRIPTION

This little addon enables thumbnails for HTML, HTM, MHTML and URL files in Windows Explorer, a feature
which has been removed from Vista.


II. INSTALLATION


Make sure you have the Visual Studio 2005 SP1 Runtime Files installed:
http://www.microsoft.com/downloads/details.aspx?familyid=200b2fd9-ae1a-4a14-984d-389c36f85647&displaylang=en

Run register.bat with Admin rights.


III. UNINSTALLATION

Run unregister.bat.



IV. DISTRIBUTION

Distribution of any of the files of this application is forbidden, without permission from Andreas Verhoeven.
Contact Andreas Verhoeven (andreasverhoeven@hotmail.com).

You should have downloaded this file from http://www.aveapps.com or from http://mpj.tomaatnet.nl/vista.